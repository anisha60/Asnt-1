import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('ggplot')
import seaborn as sns
import sklearn
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
import scipy.stats as stats
from sklearn import metrics

sns.set()

data = pd.read_csv('venv/data.csv')
raw_data = pd.DataFrame(data)
raw_data = raw_data.dropna(axis = 1)
print(raw_data)

# raw_data.info()
sns.pairplot(raw_data)
columns = raw_data.columns.tolist()
print(columns)

x_array = []
y_array = []
for c in columns:
    if c != 'SUS':
        x_array.append(c)
    else:
        y_array.append(c)

x = raw_data[x_array]
y = raw_data[y_array]

print("x array:" , x)
print("y array:", y)

x_train, x_test, y_train, y_test = train_test_split(x, y)
model = LinearRegression()
model.fit(x_train, y_train)
# print(model.coef_)
# print(model.intercept_)

# count = 0
# x_coef = {}
# for c in x_array:
#     x_coef[c] = model.coef_[0][count]
#     count+=1

# print(x_coef)
print('Intercept: \n', model.intercept_)
print('Coefficients: \n', model.coef_)


# x_coef_df = pd.DataFrame.from_dict(model.coef_, orient = 'index', columns = ['Coefficients'])
# print(x_coef_df)

x_train = sm.add_constant(x_train)
model = sm.OLS(y_train, x_train).fit()
predictions = model.predict(x_train)

print_model = model.summary()
print(print_model)

# plt.scatter(y_test, predictions)
# plt.show()
#
# plt.hist(y_test - predictions)
# plt.show()
#
# metrics.mean_absolute_error(y_test, predictions)
# metrics.mean_squared_error(y_test, predictions)
# np.sqrt(metrics.mean_squared_error(y_test, predictions))

#logistical regression
raw_data.head(5)

print()

for v in x_array:
    r_val = stats.pearsonr(x[v], y)
    print(v, ": " , r_val[0])


# sns.countplot(x = 'Gender', data = raw_data)

# sns.countplot(x = 'SUS', hue = 'Gender', data = raw_data)
# sns.countplot(x = 'SUS', hue = 'Purchase', data = raw_data)
# sns.countplot(x = 'SUS', hue = 'Duration' , data = raw_data)
# sns.countplot(x = 'SUS', hue = 'ASR_Error', data = raw_data)
# sns.countplot(x = 'SUS', hue = 'Intent_Error', data = raw_data)


















import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('data.csv')

df.isna().sum()
np.seterr(divide='ignore', invalid='ignore')

sns.histplot(data=df['SUS'], palette='bright')
plt.show()

y = df['SUS'].to_numpy()
print(y)

X = df.drop('SUS', axis = 1)
X = X.drop('Unnamed: 6', axis = 1).to_numpy()
print(X)


from sklearn.preprocessing import StandardScaler
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn import metrics

scale = StandardScaler()
scaled_X = scale.fit_transform(X)
# print(scaled_X)

X_train, X_test, y_train, y_test = train_test_split(scaled_X, y, test_size = 0.3)

# print(y_train)

from imblearn.over_sampling import SMOTE
from imblearn.over_sampling import RandomOverSampler
ros = RandomOverSampler(random_state=0)
over_sampled_X_train, over_sampled_y_train = ros.fit_resample(X_train, y_train)

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix, roc_curve, auc, classification_report

lc = LogisticRegression(class_weight="balanced")
svc = SVC(probability=True)
nbc = GaussianNB()
rfc = RandomForestClassifier()

oversample = SMOTE()
# over_sampled_X_train, over_sampled_y_train = oversample.fit_resample(X_train, y_train)

lc.fit(over_sampled_X_train, over_sampled_y_train)
svc.fit(over_sampled_X_train, over_sampled_y_train)
nbc.fit(over_sampled_X_train, over_sampled_y_train)
rfc.fit(over_sampled_X_train, over_sampled_y_train)

y_lc_predicted = lc.predict(X_test)
y_lc_pred_proba = lc.predict_proba(X_test)
# print(y_lc_pred_proba)
metrics.f1_score(y_test, y_lc_predicted, average='weighted', labels=np.unique(y_lc_predicted), zero_division = 1)

y_svc_predicted = svc.predict(X_test)
y_svc_pred_proba = svc.predict_proba(X_test)
metrics.f1_score(y_test, y_svc_predicted, average='weighted', labels=np.unique(y_svc_predicted), zero_division = 1)

y_nbc_predicted = nbc.predict(X_test)
y_nbc_pred_proba = nbc.predict_proba(X_test)
metrics.f1_score(y_test, y_nbc_predicted, average='weighted', labels=np.unique(y_nbc_predicted), zero_division = 1)

y_rfc_predicted = rfc.predict(X_test)
y_rfc_pred_proba = rfc.predict_proba(X_test)
metrics.f1_score(y_test, y_rfc_predicted, average='weighted', labels=np.unique(y_rfc_predicted), zero_division = 1)

print(classification_report(y_test, y_lc_predicted))
print(classification_report(y_test, y_svc_predicted))
print(classification_report(y_test, y_nbc_predicted))
print(classification_report(y_test, y_rfc_predicted))

models = ['Logistic Regression', 'Support Vector Machine', 'Naive Bayes Classifier', 'Random Forest Classifier']
predictions = [y_lc_predicted, y_svc_predicted, y_nbc_predicted, y_rfc_predicted]
pred_probabilities = [y_lc_pred_proba, y_svc_pred_proba, y_nbc_pred_proba, y_rfc_pred_proba]

plot = 1
#
# for model, prediction, pred_proba in zip(models, predictions, pred_probabilities):
#     disp = ConfusionMatrixDisplay(confusion_matrix(y_test.ravel(), prediction))
#     disp.plot(
#         include_values=True,
#         cmap='gray',
#         colorbar=False
#     )
#     disp.ax_.set_title(f"{model} Confusion Matrix")
#
# plt.figure(figsize=(30, 15))
# plt.suptitle("ROC Curves")
# plot_index = 1
#
# for model, prediction, pred_proba in zip(models, predictions, pred_probabilities):
#     fpr, tpr, thresholds = roc_curve(y_test, pred_proba[:, 1])
#     auc_score = auc(fpr, tpr)
#     plt.subplot(3, 2, plot_index)
#     plt.plot(fpr, tpr, 'r', label='ROC curve')
#     # pyplot.figure(figsize=(5, 5))
#     plt.title(f'Roc Curve - {model} - [AUC - {auc_score}]', fontsize=14)
#     plt.xlabel('FPR', fontsize=12)
#     plt.ylabel('TPR', fontsize=12)
#     plt.legend()
#     plot_index += 1
# plt.show()





import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
import pycountry
from pygal_maps_world.maps import World
from shapely.geometry import Point, Polygon
# import cairosvg

wm = World()
wm.force_uri_protocol = 'http'


articles = pd.read_csv("venv/articleInfo.csv")
authors = pd.read_csv("venv/authorInfo.csv")

merged = pd.merge(articles, authors, on = 'Article No.', how = 'outer')
remove_article_dupes = merged.drop_duplicates(subset =['Article No.'])
print(remove_article_dupes)

year_no = []
years = [int]

years_list = remove_article_dupes['Year'].unique().tolist()

for i in years_list:
        year_no.append((i, remove_article_dupes['Year'].value_counts()[i]))

print(year_no)


#plot yearly publications
yearly_publication = pd.DataFrame(year_no, columns = ['Year', 'Articles Published'])
yearly_publication.plot(x ='Year', y ='Articles Published', kind = 'bar')
print(yearly_publication)
plt.show()

year_citations = []
years = []

#plot yearly citations
for i in years_list:
        new_df = remove_article_dupes.loc[remove_article_dupes['Year'] == i]
        citation_count = new_df['Citation'].sum()
        year_citations.append((i, citation_count))

print(year_citations)
yearly_citations = pd.DataFrame(year_citations, columns = ['Year', 'Citations'])
yearly_citations.plot(x = 'Year', y = 'Citations', kind = 'bar')
print(yearly_citations)
plt.show()

#plot publications on map
article_nos = authors['Article No.'].tolist()
country_list = merged['Country'].unique().tolist()


country_dict = {}
# for i in article_nos:
#         nos = authors.loc[authors['Article No.'] == i]
#         countries = nos['Country'].unique().tolist()
#         country_dict[i] = countries

correct_country_dict = {}
authors_dict = {}
country_stats = {}
hindex_dict = {}
for c in country_list:
        unis_dict = {}
        this_country = merged.loc[merged['Country'] == c]
        affiliation_count = this_country.groupby('Author Affiliation').count()
        affiliation_count = affiliation_count.sort_values(by = 'Article No.', ascending = False)
        h_index = affiliation_count.sort_values(by = 'h-index', ascending = False )
        print(h_index)
        # affil_list = this_country['Author Affiliation'].tolist()
        # print(affil_list)
        try:
                the_data = affiliation_count.iloc[0:5]
                top_h = h_index.iloc[0:5]
        except:
                try:
                        max = affiliation_count.shape[0]
                        max_h = h_index.shape[0]
                        if max == 1:
                                the_data = affiliation_count.iloc[0]
                                h_data = h_index.iloc[0]
                        else:
                                the_data = affiliation_count.iloc[0:max]
                                h_data = h_index.iloc[0:max_h]

                except:
                        continue
        count = 0
        print(the_data)
        for i, row in the_data.iterrows():
                inst = i
                num = the_data.iloc[count]['Article No.']
                unis_dict[inst] = num
                count +=1

        h_count = 0
        for i, row in h_data.itterrows():
                author = i



        print(authors_dict)
        correct_country_dict[c] = this_country.shape[0]
        country_stats[c] = unis_dict
        hindex_dict[c] = h_data

print(country_stats)


print(correct_country_dict)

print("Unique countries: ")
# unique_countries = {}
# for key in country_dict:
#         j = country_dict[key]
#         for k in j:
#                 if k not in unique_countries:
#                                 unique_countries[k] = 1
#                 else:
#                         unique_countries[k] += 1
#
#
# print(unique_countries)
country_codes = {}

for key in correct_country_dict:
        try:
                country_code = pycountry.countries.get(name=key).alpha_2.lower()
                country_codes[country_code] = correct_country_dict[key]
        except:
                try:
                        country_code = pycountry.countries.search_fuzzy(key)[0].alpha_2.lower()
                        country_codes[country_code] = correct_country_dict[key]

                except:
                        print(key, "exception")
                        try:
                                current = country_codes['NONE']
                                country_codes['NONE'] = current + correct_country_dict[key]
                        except:
                                country_codes['NONE'] = correct_country_dict[key]
        
print("country codes:" , country_codes)

country_density = pd.DataFrame(country_codes.items(), columns = ['Country' ,'Density'])
print(country_density)

wm.add('Publications', country_codes)
wm.render_in_browser()











